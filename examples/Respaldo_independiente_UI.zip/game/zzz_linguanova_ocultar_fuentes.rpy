﻿# SPDX-License-Identifier: GPL-3.0-or-later
# Generated and installed automatically by LinguaNova.
# Font files, paths and translate-python font blocks remain available.

init -999 python:
    # Older Font Injector versions put assets inside tl/linguanova_fonts.
    # Ren'Py also discovers languages from resource paths. Hide ONLY our own
    # resource folders, including from the game's original automatic selector.
    # Keep every font path/file intact; the Russian font continues to work.
    _lntl_resource_folders = set(["linguanova_font", "linguanova_fonts", "linguanova_mod_fonts"])
    if not getattr(renpy.known_languages, '_lntl_resource_filter', False):
        _lntl_original_known_languages = renpy.known_languages

        def _lntl_known_languages():
            return set(code for code in _lntl_original_known_languages()
                       if code and code.lower() not in _lntl_resource_folders)

        _lntl_known_languages._lntl_resource_filter = True
        renpy.known_languages = _lntl_known_languages
